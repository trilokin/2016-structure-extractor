/* (C) 2016 Trilok Inakota */

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
/* "readdir" etc. are defined here. */
#include <dirent.h>
/* limits.h defines "MAX_PATH". */
#include <limits.h>
#include "db_string.h"

static int nobraces = 0;

/* Need to clean code */
int val_line (char *buf, size_t linecount)
{
  char local_buf[MAX_BUF];
  char *q1 = NULL;
  char *q2 = NULL;


  q1 = (char *)StrStr1 (buf, "struct");  
  
  /* check this is not in braces */
  if ( (q1!=NULL) && 
       ((*(q1-1) == '(') || (q2=StrStr1(buf,")") != NULL)))
    return DBNL;

  /* check this is not a substring of any
   * keyword
   */
  if ( (q1!=NULL) && (*(q1+6) !=' ') )
    return DBNL;

  /*check this is not a Macro */
  if ((q1!=NULL) && 
      (q2=StrStr2(buf, "struct","\\") != NULL) ||
      (q2=StrStr2(buf, "struct","}") != NULL))
    return DBNL;
  
 
  q2 = q1; 
  while ((q2 !=NULL) && (*q2 != '\n')) {
     
      if (*q2 == ';') 
        return DBD;	
      else if (*q2 == '{') {
        return DBEC;
      }
 
     q2++;
  }

  return DBNL;
}


int readLine (int fd, char *buf, size_t bufSize)
{
   int     ch = 0;
   size_t  i = 0;
   size_t  bytes_read = 0;

   if (bufSize < 0)
     return ESIZE;

   while ((char)ch!= '\n' ){

     bytes_read = read (fd, &ch, 1);
    
      if (bytes_read <= 0) {
         perror ("EOF");
         return 0; 
       }
       buf[i++] = (char)ch;
       bytes_read++;
       
       if ((char)ch == -1)
         break;
   }
   i = 0; 
  return bytes_read;
}

int truncateLine (int fd, char *buf, size_t bufSize, int ld)
{ 
    char *p1 = NULL;
    char *p2 = NULL;

   /* check inner unnamed unions and structs */
    if ((p1=StrStr1 (buf, "{")) != NULL) {
       nobraces++;
    }

    if ((p1=StrStr1 (buf, "};")) != NULL) {
      nobraces--; 
      if (!nobraces) {
        write (ld, p1, strlen(p1));   
        return INVALID;   
      }
    } 
    else if (p2 = StrStr2(buf,"}",";")) {
      nobraces--; 
      if (!nobraces) {
        write (ld, StrStr1(buf,"}"), strlen(StrStr1(buf,"}") ));    
        return INVALID;
      }   
    } 
    else if (p2 = StrStr1(buf,"}")) {
      nobraces--; 
      if (!nobraces) {
        return INVALID;   
       }
     }

   return VALID;
}

int db_eof (char *buf, size_t bufSize)
{
  size_t i = 0;

  while (i < bufSize) {
    if (buf[i] == -1)
      return VALID;
    i++;
  }
 
  return INVALID;
}

  

int create_db (char *filename, int ld)
{
 
   int    fd, flag =1 ;  
   int    status = -1;
   size_t linecount = 1;
   char   buffer[MAX_BUF] = {0};
   size_t offset = 0; 
   size_t bytes_read = 0;

   fd = open (filename, O_RDONLY);

   if ( fd < 0 ) {
     perror ("File open:"); 
     return EOPEN;
   }

  do {
   
    int    more = 1;

    /* Read the next line's worth of bytes.  */
    memset (buffer, 0, sizeof (buffer)); 
    bytes_read = readLine (fd, buffer, sizeof (buffer));
    linecount++;
    if (bytes_read > 0)    
      status = val_line (buffer, linecount);
    else
      status = DEOF;  

    switch (status) {

	case DBNL :
	case DBD  :
    		  /* Keep count of our position in the file.  */ 
		  offset += bytes_read; 
		  continue; 
        case DBEC :
                   more = truncateLine (fd, buffer, sizeof (buffer), ld);  
                   while (more) {
                    write (ld, buffer, strlen(buffer));    
                    if (more) {
	                  memset (buffer, 0, sizeof (buffer));
        	          bytes_read = readLine (fd, buffer, sizeof (buffer)); 
                	  linecount++; 
			  offset += bytes_read; 
                          more = truncateLine (fd, buffer, sizeof (buffer), ld);                          
                          /* Keep count of our position in the file.  */ 
                      }  
                  }
                  break;
       case DEOF : 
                  flag = 0; 
                  break;  
    }

    /* Keep count of our position in the file.  */ 
    offset += bytes_read;

  } while ( (flag!=0) && (!db_eof (buffer, sizeof (buffer))));

  close (fd); 
  close (ld);
}

/* List the files in "dir_name". */
static void
list_dir (const char * dir_name)
{
    char filepath[MAX_PATH] = {0};
    char DBdirpath[MAX_PATH] = {0};
    char loc[MAX_PATH] = {0};
    char mkcmd[MAX_PATH] = {0};

    DIR  * d;
    DIR  * DBd;
  
    int ld = 0;
    int  mkdir_val = 0;

    snprintf (DBdirpath, MAX_PATH, "/tmp/%s", dir_name);
    /* Open the directory specified by "dir_name". */
    d = opendir (dir_name);

    /* Check it was opened.  */
    if (d) {

     sprintf (mkcmd, "mkdir -p %s", DBdirpath);
     mkdir_val = system(mkcmd);
	
     if (mkdir_val < 0) {
        exit (EXIT_FAILURE);
     } 
 
    while (1) {
        struct dirent * entry;
        const char * d_name;

        /* "Readdir" gets subsequent entries from "d". */
        entry = readdir (d);
        if (! entry) {
            /* There are no more entries in this directory, so break
               out of the while loop. */
            break;
        }
        d_name = entry->d_name;
        /* Print the name of the file and directory. */
        printf ("1:%s/%s\n", dir_name, d_name);

        /* See if "entry" is a subdirectory of "d". */

        if (entry->d_type & DT_DIR) {

            /* Check that the directory is not "d" or d's parent. */
            
            if (strcmp (d_name, "..") != 0 && strcmp (d_name, ".") != 0) {
                int path_length;
                char path[PATH_MAX];
 
                path_length = snprintf (path, PATH_MAX,
                                        "%s/%s", dir_name, d_name);
                printf ("%s\n", path);
                if (path_length >= PATH_MAX) {
                    fprintf (stderr, "Path length has got too long.\n");
                    exit (EXIT_FAILURE);
                }
                /* Recursively call "list_dir" with the new path. */
                list_dir (path);
            }
        } else { /* entry is a file */
            /* consider only .c and .h files and 
             *  ignore rest of the files 
             */
            if ((StrStr1(entry->d_name, ".c")) 
                || (StrStr1(entry->d_name, ".h"))) {
              snprintf (filepath,MAX_PATH, "%s/%s\0", dir_name, d_name);
              printf ("%s\n",filepath);
              snprintf (loc, MAX_PATH, "/tmp/%s\0", filepath);
              ld = open(loc, O_CREAT | O_WRONLY | O_RDONLY);
              if (ld > 0)
              create_db (filepath, ld);
           }
        }
    }
    /* After going through all the entries, close the directory. */
    if (closedir (d)) {
        fprintf (stderr, "Could not close '%s': %s\n",
                 dir_name, strerror (errno));
        exit (EXIT_FAILURE);
    }
   } else if (!d) {
        create_db (dir_name, NULL);
   }

}

int main (int argc, char *argv[])
{
 
    if ( argc>1 )   
    list_dir (argv[1]);
    return 0;
}
