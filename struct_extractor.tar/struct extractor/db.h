
#ifndef	 __DB_H
#define	 __DB_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stddef.h>

#define u_int32t	unsigned int
#define u_char		unsigned char
#define UBYTE		u_char
#define BYTE		char


#define lfree(fn, p)	free(p); 


#define MAX_BUF		2048 	/* MAX coloumn size */
#define MAX_PATH	100
#define DBFILE		".temp"


/* Errors */
#define VALID		1
#define INVALID		0

#define ESIZE  		-1
#define EREAD		-2
#define EOPEN		-3
	

#define openRD(s)	open (s, O_RDONLY);
#define FOR (n)`	for (int i=0; i<n; i++ )
    
/*  
struct dbfn {

   (void)(*match)(int,  char *, char *);
   (void)(*read)(char *, char *);
   (char *)(*search)(char *, char *);
};
*/

#endif /* __DB_H */





