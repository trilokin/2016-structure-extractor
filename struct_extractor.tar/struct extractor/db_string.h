/* (C) 2016 Trilok Inakota */

#ifndef __DB_STRING_H

#define __DB_STRING_H

#include "db.h"

#define DBD	0
#define	DBEC	1
#define	DBNL	2
#define DEOF    3
/* Errors */



char* StrStr1(const char *, const char *); 

unsigned int StrLen(const char *);

int StrCpy (const char *, char *);


int StrCpyMatch (char *, 
                 char *,
                 char *);

char* StrStr2(const char *,
              const char *,
              const char *);


#endif /* __DB_STRING_H */
