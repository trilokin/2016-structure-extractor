/* (C)  2016 Trilok Inakota */

#include "db.h"
#include "db_string.h"

/* Find the string length for a
 * given string
 */

unsigned int StrLen(const char *s)
{
  if (s == NULL)
    return 0;
  
  char *p1 = (char*)s;
  int len = 0; 
  
  while (*p1 != '\0') {
    len++;
    p1++;
  }
  
  return len;
}

/*  str = xyzxyzstruct
    target = "struct"

    return "struct";
*/

char* StrStr1(const char *str, const char *target) 
{
  if (!*target) 
     return (char *)str;

  char *p1 = (char*)str, *p2 = (char*)target;
  char *p1Adv = (char*)str;

  while (*++p2)
    p1Adv++;

  while (*p1Adv) 
  {
    char *p1Begin = p1;
    p2 = (char*)target;
    while (*p1 && *p2 && *p1 == *p2) {
      p1++;
      p2++;
    }
    if (!*p2)
      return p1Begin;
    p1 = p1Begin + 1;
    p1Adv++;
  }
  return NULL;
}



char* StrStr2(const char *str, 
              const char *target1, 
              const char *target2) 
{
  if (!*target1) 
     return (char *)str;

  if (!*target2) 
     return (char *)str;

  char *p1 = (char *)StrStr1 (str, target1);

  if (p1 == NULL)  
    return NULL;
 
  char *p2 = (char *)StrStr1 (p1, target2);
  
  if (p2 == NULL)
    return NULL;

  return (char *)p2;
}

int StrCpy (const char *src, char *dest)
{ 
   unsigned int bytes = 0;

   if ((src == NULL) || (dest ==NULL))
     return -1;
 
   char *p1 = (char*)src;
   char *p2 = (char*)dest;

   while (*p1 != '\0') {
     *p2 = *p1;
      p1++;
      p2++;
      bytes++;
   }    
  
  *p2 = '\0'; 

  return bytes;

}

int StrCpyMatch (char *src1, 
                 char *src2,
                 char *dest)
{ 
   char *p = NULL;
   char *q = NULL;
   char *r = NULL;
   unsigned int diff = 0;


   if ((src1 == NULL) || (src2 == NULL) 
       || (dest ==NULL))
     return -1;
 
   p = (char *)src1;
   q = (char *)src2;
   r = (char *)dest;

   diff = q - p + 1;

   while (p != (src1 + diff)) {
     *r = *p;
     p++;
     r++;
  }

  return 0; 
 
}
